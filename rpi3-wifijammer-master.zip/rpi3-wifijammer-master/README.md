# RPi3 WifiJammer
WiFi Jammer Script for Raspberry Pi 3 Model B

This script is only here to make my life easier, (mattfrias), so I wont have to be bookmarking links for my projects.

Original GitHub Repository can be found at https://github.com/DanMcInerney/wifijammer

wifijammer.py belongs to DanMcInerney and holds the licsense, Copyright (c) 2014, Dan McInerney All rights reserved.
